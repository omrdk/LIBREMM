## LIBREMM PLAYER
QML based lightweight media player.
### How to build for Linux
`sudo apt-get install qtbase5-dev qtdeclarative5-dev`
 
`cd build`<br>
`cmake ..`<br>
`make`<br>
`sudo make install`<br>
`LIBREMM`
### Shortcuts
<table>
<tr>
  <th>Space</th><th>play/pause</th>
</tr>
<tr>
  <th>Left</th><th>-10s</th>
</tr>
<tr>
  <th>Right</th><th>+10s</th>
</tr>
<tr>
  <th>Up</th><th>inc. %10 vol</th>
</tr>
<tr>
  <th>Down</th><th>dec. %10 vol</th>
</tr>
<tr>
  <th>O</th><th>open</th>
</tr>
<tr>
  <th>M</th><th>mute</th>
</tr>
</table>

### Tasks
- [x] Subtitle catching
- [x] Subtitle costumization
- [ ] Subtitle file encoding
- [ ] Equilazer
- [ ] Media list
- [x] Volume popup
