#include <iconv.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "backoffice.h"

#include "unicode/ucnv.h"
#include "unicode/ucnv_err.h"

using namespace std;

using namespace icu_69;

std::vector<SubtitleItem*> sub;

BackOffice::BackOffice(QObject *parent/*, QMediaPlayer *qmlplayer*/)
{
    //player = qmlplayer;

    m_playlist = new PlaylistModal(this);   // no need to delete
    //convCode();

    //UChar conv_name[] = u"cp1254";

    //int count = ucnv_countAvailable();
    //qDebug() << count;
    UErrorCode err = U_ZERO_ERROR;
    UConverter *conv = ucnv_open("cp1254", &err);



}

///*Calls through createConverter */
//U_CAPI UConverter* U_EXPORT2
//ucnv_open (const char *name, UErrorCode * err)
//{
//    UConverter *r;
//    if (err == NULL || U_FAILURE (*err)) {
//        return NULL;
//    }
//    r =  ucnv_createConverter(NULL, name, err);
//    return r;
//}

BackOffice::~BackOffice()
{

}


void BackOffice::readSub(QString url)
{
    QString abs = url.mid(7); qDebug() << abs;
    SubtitleParserFactory *subParserFactory = new SubtitleParserFactory(abs.toStdString());
    SubtitleParser *parser = subParserFactory->getParser();
    sub = parser->getSubtitles();
}

auto BackOffice::getSubText(double pos_ms) -> QString
{
    QStringList textandtime;
    for(SubtitleItem *element : sub)
    {
        double T_START = element->getStartTime();
        double T_STOP  = element->getEndTime();

        if( (T_START <= pos_ms) && (pos_ms <= T_STOP))
        {
            return QString::fromStdString(element->getText());
        }
    }
    return "";
}


void BackOffice::convCode()
{
    iconv_t conv;
    int     len;

    //const char* to   = ;
    //const char* from = ;

    if ((conv = iconv_open("UFT-8//IGNORE", "ISO_8859-1")) == (iconv_t)(-1))
    {
       //fprintf(stderr, "Cannot open converter from %s to %s\n", to, from);
       //exit(8);
    }

    QFile file("/home/merdak/Downloads/The.Book.of.Boba.Fett.S01E03.1080p.WEB.h264-KOGi[rarbg]/The.Book.of.Boba.Fett.S01E03.720p.WEB.x265-MiNX.srt");
    if(!file.open(QIODevice::ReadOnly)) { qDebug() << "Could not opened!"; return; }
    QByteArray ba;
    while (!file.atEnd())
    {
        ba += file.readLine();
    }
    file.close();

    //qDebug() << ba.data();
    char *input_buf = ba.data();

    //std::puts(input_buf);
    char output_buf[ba.size()];
    std::size_t input_buf_left = ba.size();
    std::size_t output_buf_left = ba.size();
    char *input_buf_ptr = input_buf;
    char *output_buf_ptr = output_buf;

    len = iconv(conv, &input_buf_ptr, &input_buf_left, &output_buf_ptr, &output_buf_left);

    //std::puts(output_buf);

    if (len == -1)
    {
       fprintf(stderr, "Error in converting characters\n");
       //exit(8);
    }

    *output_buf_ptr = '\0';

    for (const char *c = output_buf; c != output_buf_ptr; c++)
    {
      std::printf("%02hhX ", *c);

    }


    std::putchar('\n');

    std::puts(output_buf);
    iconv_close(conv);

    QFile out("/home/merdak/Downloads/The.Book.of.Boba.Fett.S01E03.1080p.WEB.h264-KOGi[rarbg]/out.srt");
    if(!out.open(QIODevice::Append)) { qDebug() << "Could not opened!"; return; }
    out.resize(0);
    out.write((char *)output_buf);
    out.close();



}





